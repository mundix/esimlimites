-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: laravel
-- ------------------------------------------------------
-- Server version	5.7.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES UTF8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `applications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plan_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `iccid` bigint(20) DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `payment` bigint(20) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applications`
--

LOCK TABLES `applications` WRITE;
/*!40000 ALTER TABLE `applications` DISABLE KEYS */;
INSERT INTO `applications` VALUES (1,'Edmundo','Pichardo','Rep. Dom','Plan 2',1321321321,'Claro','asdasdad',1,530,2,'2023-01-13 02:28:30','2023-01-13 02:28:30'),(2,'Edmundo','Pichardo','Rep. Dom','Plan 2',1321321321,'Claro','asdasdad',1,530,2,'2023-01-13 09:36:18','2023-01-13 09:36:18'),(3,'Juan','Perez','Rep. Dom','Plan 2',1321321321,'Claro','asdasdad',1,530,2,'2023-01-31 16:18:08','2023-01-31 16:18:08');
/*!40000 ALTER TABLE `applications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client_orders`
--

DROP TABLE IF EXISTS `client_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_contact` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_order_number` bigint(20) unsigned DEFAULT NULL,
  `channel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_imei` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qr_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client_orders`
--

LOCK TABLES `client_orders` WRITE;
/*!40000 ALTER TABLE `client_orders` DISABLE KEYS */;
INSERT INTO `client_orders` VALUES (1,'ce.pichardo@gmail.com','Edmundo Pichardo','8492065381',1233454654,'stand','092839859348593','link:content','airalo-template_v','2023-01-13 08:46:09','2023-01-13 08:46:09'),(2,'ce.pichardo@gmail.com','Edmundo Pichardo','8492065381',1233454654,'stand','092839859348593','link:content','airalo-template_v','2023-01-13 08:46:23','2023-01-13 08:46:23');
/*!40000 ALTER TABLE `client_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (11,'2014_10_12_100000_create_password_resets_table',1),(12,'2019_12_14_000001_create_personal_access_tokens_table',1),(13,'2023_01_11_000001_create_permissions_table',1),(14,'2023_01_11_000002_create_roles_table',1),(15,'2023_01_11_000003_create_users_table',1),(16,'2023_01_11_000004_create_permission_role_pivot_table',1),(17,'2023_01_11_000005_create_role_user_pivot_table',1),(18,'2023_01_11_000006_create_qa_topics_table',1),(19,'2023_01_11_000007_create_qa_messages_table',1),(20,'2023_01_13_013107_create_applications_table',1),(21,'2023_01_13_023832_create_client_orders_table',2),(22,'2016_06_01_000001_create_oauth_auth_codes_table',3),(23,'2016_06_01_000002_create_oauth_access_tokens_table',3),(24,'2016_06_01_000003_create_oauth_refresh_tokens_table',3),(25,'2016_06_01_000004_create_oauth_clients_table',3),(26,'2016_06_01_000005_create_oauth_personal_access_clients_table',3),(27,'2023_01_31_153450_create_products_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_access_tokens`
--

LOCK TABLES `oauth_access_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_access_tokens` DISABLE KEYS */;
INSERT INTO `oauth_access_tokens` VALUES ('8b310216f652cbe17532c58bb72dfd13689e286e8cd4e856b06b4345352b9e8d414e2eafdcba755e',1,1,'MyApp','[]',0,'2023-01-31 16:05:54','2023-01-31 16:05:54','2024-01-31 16:05:54');
/*!40000 ALTER TABLE `oauth_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `client_id` bigint(20) unsigned NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_auth_codes`
--

LOCK TABLES `oauth_auth_codes` WRITE;
/*!40000 ALTER TABLE `oauth_auth_codes` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_auth_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_clients`
--

LOCK TABLES `oauth_clients` WRITE;
/*!40000 ALTER TABLE `oauth_clients` DISABLE KEYS */;
INSERT INTO `oauth_clients` VALUES (1,NULL,'Laravel Personal Access Client','Q23nVEsO3PdmQM9Byp2MzkwchuO8dFoWrma1xb46',NULL,'http://localhost',1,0,0,'2023-01-31 15:23:13','2023-01-31 15:23:13'),(2,NULL,'Laravel Password Grant Client','YUYEZ3kcFycK3AfKMZwPJO7xv1f1tE4jirbr6yPT','users','http://localhost',0,1,0,'2023-01-31 15:23:13','2023-01-31 15:23:13');
/*!40000 ALTER TABLE `oauth_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_personal_access_clients`
--

LOCK TABLES `oauth_personal_access_clients` WRITE;
/*!40000 ALTER TABLE `oauth_personal_access_clients` DISABLE KEYS */;
INSERT INTO `oauth_personal_access_clients` VALUES (1,1,'2023-01-31 15:23:13','2023-01-31 15:23:13');
/*!40000 ALTER TABLE `oauth_personal_access_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_refresh_tokens`
--

LOCK TABLES `oauth_refresh_tokens` WRITE;
/*!40000 ALTER TABLE `oauth_refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `oauth_refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permission_role` (
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  KEY `role_id_fk_7863547` (`role_id`),
  KEY `permission_id_fk_7863547` (`permission_id`),
  CONSTRAINT `permission_id_fk_7863547` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_id_fk_7863547` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission_role`
--

LOCK TABLES `permission_role` WRITE;
/*!40000 ALTER TABLE `permission_role` DISABLE KEYS */;
INSERT INTO `permission_role` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10),(1,11),(1,12),(1,13),(1,14),(1,15),(1,16),(1,17),(2,17);
/*!40000 ALTER TABLE `permission_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'user_management_access',NULL,NULL,NULL),(2,'permission_create',NULL,NULL,NULL),(3,'permission_edit',NULL,NULL,NULL),(4,'permission_show',NULL,NULL,NULL),(5,'permission_delete',NULL,NULL,NULL),(6,'permission_access',NULL,NULL,NULL),(7,'role_create',NULL,NULL,NULL),(8,'role_edit',NULL,NULL,NULL),(9,'role_show',NULL,NULL,NULL),(10,'role_delete',NULL,NULL,NULL),(11,'role_access',NULL,NULL,NULL),(12,'user_create',NULL,NULL,NULL),(13,'user_edit',NULL,NULL,NULL),(14,'user_show',NULL,NULL,NULL),(15,'user_delete',NULL,NULL,NULL),(16,'user_access',NULL,NULL,NULL),(17,'profile_password_edit',NULL,NULL,NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detail` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'Bethel Walter','Quos voluptatum et error natus doloremque minus esse. Esse fugit fugit molestias voluptatem mollitia dolores quis cupiditate. Repellendus quae eum qui maxime libero.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(2,'Penelope Gulgowski','Dolorem dolorum dolore rem molestias voluptas doloremque. Numquam sit consectetur voluptatem et dignissimos et autem est.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(3,'Dr. Elliott Balistreri II','Enim et asperiores exercitationem excepturi neque provident. Blanditiis quo fugit ad ullam. Quis pariatur reiciendis deleniti laborum magnam optio. Fugiat eos quia perferendis.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(4,'Prof. Kameron Smitham','Eos ipsum facilis est fugit. Molestiae consectetur et rem rerum dolorem. Sunt similique molestiae odio debitis quae quos exercitationem.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(5,'Mr. Trystan Thiel DVM','Rerum facilis excepturi sunt aspernatur. In ut iste aut error est asperiores qui sunt. Omnis enim ut amet enim quo.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(6,'Jeanie McClure II','Ut iusto similique impedit provident nobis voluptas mollitia. Omnis accusantium expedita autem aut accusantium sed. Deleniti aut doloremque quasi quia. Sunt doloribus et deleniti eum. Laborum est praesentium quia quo doloremque.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(7,'Shaun Dare','Facilis minus dolore magnam nemo adipisci non. Unde non sunt culpa ullam laborum iste. Reprehenderit ea dignissimos porro.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(8,'Makenzie Hayes I','Vitae aut explicabo expedita non. Consequatur asperiores ipsam repellendus consequuntur sunt numquam consequuntur quia. Aut voluptatem et explicabo a est. Dolorum et sit vero ut omnis ea cumque amet. Et labore soluta vel ut dolor praesentium omnis.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(9,'Trevor Leannon','Molestias qui eum dignissimos possimus iusto voluptas. Voluptatem ut reiciendis voluptatum quo minus. Harum distinctio assumenda alias porro deserunt. Voluptate dolores esse odit dolorum perspiciatis.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(10,'Donavon Ondricka','Voluptas eos mollitia quaerat non doloremque. Dolore asperiores beatae id dicta eum hic. Repudiandae tempore tempora iusto maxime nam mollitia.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(11,'Mrs. Karelle Bahringer DDS','Voluptatem atque quia sed distinctio inventore dolore earum. Laborum vel excepturi eveniet. Facere fugiat et sed maxime qui consequatur. Omnis dolorem repudiandae non commodi qui molestias qui.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(12,'Dr. Jeanette Pagac MD','Eveniet et repudiandae ut odio nulla. Est facilis doloremque nulla eos ut sunt est nostrum. In et et id sint. Aut odit perferendis et voluptatibus. Eos commodi provident est laudantium quisquam sed in.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(13,'Miss Janelle Friesen','Et eligendi autem sint magnam reprehenderit culpa atque voluptatem. Non eum dolorem inventore id quasi voluptatem eos. Inventore veniam quisquam cumque libero officiis ab.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(14,'Mabelle Vandervort','Unde aut unde placeat cupiditate repellendus in. Labore impedit incidunt consequatur excepturi. Optio ut ratione magnam porro a modi.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(15,'Prof. Juana Walsh IV','Enim accusamus ex ad nesciunt repellendus consectetur. Dolor doloribus est illum quibusdam. In et eum dolorum aliquam veritatis aut voluptatum. Quia aut velit eos explicabo maiores molestias.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(16,'Raphaelle Keebler','Nesciunt et ut qui voluptatibus quo. Rem laboriosam inventore qui molestiae voluptas rerum est. Dolores voluptatem vel veniam vel aliquam. Enim nisi voluptatem aut.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(17,'Mrs. Patsy Schmeler I','Ipsam fugit atque dolorem corrupti voluptatem. Id nihil hic unde aperiam. Et dolorem et nemo cumque mollitia dolorum iusto.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(18,'Karelle Bashirian','Inventore accusamus quo sit consequatur quos quis. Quod voluptas laborum perferendis animi exercitationem officiis quae. Labore fuga consequatur laborum provident modi. Quis rerum beatae sit et totam ea.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(19,'Daniela Torp','Dicta suscipit sunt eos accusantium qui qui. Doloribus nisi suscipit animi rerum. Ullam repudiandae temporibus sunt molestiae qui ipsum velit. Porro doloremque optio ipsum ullam.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(20,'Alfred Schiller','Eveniet minus quia quis molestias. Natus officiis ut in labore sed laboriosam sunt. Et nihil et nesciunt consequatur omnis hic. Consequuntur perferendis repellendus a sit quibusdam assumenda.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(21,'Emmett Goyette','Aut beatae commodi vitae sit. Ut ducimus veniam qui inventore.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(22,'Addie Bartoletti','Quia et facilis reiciendis natus consequatur non. Aut maiores et labore placeat omnis. Quis aut labore accusamus deleniti.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(23,'Dr. Alysa Bogan III','Tempore cum ipsum debitis aspernatur mollitia. At iusto molestiae commodi sint similique. Quibusdam dolor praesentium voluptas.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(24,'Shawn Hansen','Qui delectus quia molestiae cum qui. Non mollitia voluptatum labore qui repellendus aut ipsa. Iure non est id labore inventore eligendi voluptates sunt.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(25,'Electa Trantow','Dolorem quis exercitationem praesentium eum aliquam perspiciatis minima. Est eius voluptatem corrupti voluptatem laudantium molestiae. Aut atque possimus alias architecto autem.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(26,'Prof. Rowena Schimmel','Assumenda quia et unde voluptas a porro. Deserunt labore eum et non ut officiis animi. Asperiores in praesentium molestias reiciendis veniam.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(27,'Miss Margaretta Trantow','Vitae voluptas iure porro magnam expedita sint. Vero minima non repudiandae eveniet voluptatem eveniet.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(28,'Carolina Bode','Libero accusantium tenetur qui sunt accusamus porro. Voluptatem distinctio qui et velit officia. Et veniam ut vitae qui aliquid. Qui quidem sed sunt ullam unde excepturi fugit.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(29,'Karson Hyatt MD','Praesentium enim occaecati consectetur rerum. Ex sequi nemo qui quis amet iure eveniet consequatur. Consequuntur magnam voluptas mollitia aut ut sunt ea. Error error hic corporis.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(30,'Ellen Bradtke','Eveniet asperiores ullam vel rem et facere. Dolore sunt illum ex autem incidunt ut suscipit eveniet. Ipsum voluptas sit ducimus facere.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(31,'Prof. Arvid Erdman DVM','Illo saepe in tempora et harum in aut et. Inventore dicta autem esse. Id quam ipsa molestiae nemo et.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(32,'Prof. Nelson Terry DVM','Exercitationem quia soluta ipsam id. Explicabo non sequi omnis dolorem alias dolore. Aut earum quas rerum alias natus in. Impedit magnam ullam officia natus non dolores.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(33,'Prof. Pablo Friesen DDS','Laboriosam nisi laudantium cupiditate ut. Qui ut aliquid animi temporibus eligendi temporibus. Eligendi ullam voluptas possimus dolores recusandae dolorum.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(34,'Dejon Pacocha','Et temporibus sed eos asperiores numquam consequatur. Et neque aut laborum hic voluptas voluptate sed. Commodi accusantium laboriosam quasi accusamus.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(35,'Prof. Maximus Pfannerstill','Qui perferendis et quo nostrum dicta. Accusamus sit dolores natus quia rerum molestiae. Voluptatibus omnis maxime veritatis voluptatem totam vitae.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(36,'Hortense Becker','Sunt eos ipsa assumenda aut molestias voluptatem enim. Sunt possimus eaque ab facere quod doloribus reiciendis quasi. Temporibus sed odit sed qui.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(37,'Prof. Conor Ferry PhD','Mollitia corporis ipsa inventore temporibus fugiat natus aliquam. Accusantium id omnis natus accusantium nesciunt. Qui dolorum minus earum minus aliquid.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(38,'Austen Hills','Explicabo at molestiae architecto mollitia ratione quia deleniti inventore. Sint temporibus illum et possimus praesentium. Porro ut est nulla ex porro. Quam expedita consequatur vel explicabo necessitatibus vero.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(39,'Astrid Pagac','Est quibusdam sint porro quidem. Deleniti eum deserunt nam eos voluptatem sit. Omnis molestiae consequatur aut amet ratione.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(40,'Julian Smitham','Est quis sed aut aperiam nostrum debitis ex. Qui velit non consequatur ut. Quia at est et quod aliquid voluptatem.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(41,'Alek Little','Possimus aut sunt et rerum magni est. Eum officia non quis. Eveniet adipisci dolore in omnis saepe. Ipsum est id velit soluta velit laudantium.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(42,'Felipa Hessel','Deleniti sit totam corrupti ratione. Cumque omnis dolorem at doloribus. Voluptates qui cum neque quis qui. Repellat necessitatibus alias autem.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(43,'Dr. Louisa Kutch','Voluptatibus sint doloremque ratione cumque non et. Eligendi quisquam consequatur recusandae.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(44,'Wilma Stehr','Quia qui sit consequatur accusamus dolorum iste velit. Consequatur autem nihil quis nemo nihil. Dolor nobis qui aut consequuntur laborum consequatur fugit.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(45,'Miss Imelda Eichmann V','A ab esse quos sed qui omnis nostrum. Consequuntur nam alias sit qui. Quas eos quam dolorum nulla saepe. Quo tenetur rerum assumenda soluta in et ratione.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(46,'Caroline Jones','Tenetur amet commodi quis vitae. Dolores est ipsa velit quasi fuga eius. Quam tempora ut voluptate.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(47,'Prof. Rafael Boyle IV','Dolorum autem molestiae sapiente. Vero ut minus architecto non tempore molestiae sunt. A quis ut est assumenda. Ut praesentium unde odio et vel porro.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(48,'Eloisa Hamill I','Molestiae quia fugit illum hic repellendus doloribus nulla. Officiis voluptatem ad dicta fuga quibusdam odit. Doloribus reprehenderit aut quo placeat et numquam. Exercitationem ducimus illum suscipit labore unde.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(49,'Donnie McDermott','Doloremque quaerat autem possimus mollitia praesentium. Recusandae atque dicta temporibus voluptatem qui eius dolor.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(50,'Mrs. Lesly Padberg DDS','Doloremque cumque dolorum recusandae vel ut. Maiores maiores consequuntur quis enim porro et. Aliquam optio eligendi quasi voluptas blanditiis maiores et. Id dolorem asperiores esse aut nam.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(51,'Mrs. Meaghan Huels','Qui dolores laborum officia temporibus ut. Nihil velit quibusdam et a temporibus nihil. Sint atque aspernatur et tempore libero similique sapiente est. Dolorum qui perferendis quia earum.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(52,'Arnold Hettinger','Modi cumque cumque qui omnis sed. Dolor labore deserunt aut ratione ut facere. Repellat odit quidem dignissimos dolor quia omnis. Et vero quam delectus dolores sapiente vitae molestiae.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(53,'Giovanna Schaden','Rerum odit delectus accusantium quia voluptate. Inventore aperiam vel omnis ad. Eos maiores iusto id exercitationem officiis voluptas. Similique tenetur possimus officia quia ex adipisci vitae.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(54,'Georgianna Bernhard','Facere illum consequatur ex facilis saepe. Quia quas architecto quasi labore sed. Adipisci iusto illo eum aut. Nobis totam itaque nobis a vel.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(55,'Zackary Nader II','Ea harum ad ipsa sequi rerum. Consequatur quisquam asperiores dolorem quia. Quisquam omnis vero molestias rerum sed fugiat.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(56,'Prof. Billy Huel V','Ut tenetur ea cumque voluptatem doloribus quam. Quos quidem dolor dolor est odit voluptas. Distinctio officiis quis repellat et. Et adipisci deserunt assumenda consectetur ex recusandae.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(57,'Mrs. Aniya Champlin','Accusantium deserunt vel quia in dolor. Delectus iusto praesentium quisquam. Eligendi exercitationem ut omnis sint molestiae deserunt ea praesentium. Similique aut sunt et.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(58,'Bradley Will MD','Fugit et consequatur culpa assumenda vel. Voluptas architecto recusandae consequatur incidunt sequi culpa. Ut nisi voluptate rerum iure.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(59,'Beryl Reichert','Quas eos sequi voluptas pariatur rerum. Nam est similique aliquid. Eum beatae rerum dolore qui quo aut numquam excepturi. Et et et vel est rerum.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(60,'Dr. Jayce Eichmann','Optio amet deserunt eveniet voluptatem reiciendis explicabo. Officiis distinctio deserunt minima. Nobis unde aut possimus quae sint qui quas.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(61,'Cruz Barton','Quidem unde aut ullam tempore et sit unde expedita. Dolorem id ut eveniet. Vero eveniet ad sint similique dolores nemo. Ratione velit error sequi autem. Et a porro tenetur consequuntur suscipit.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(62,'Ms. Jaqueline Bernhard','Autem animi qui consequatur non laboriosam aperiam minima. Rerum vel modi et cupiditate voluptate quam. Aliquam et cumque tempora facilis.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(63,'Katelynn Ernser','Quo error quo ratione corporis aut aut. Eos qui deserunt nulla et nulla id nisi. Dolorem cupiditate quia praesentium quia in fuga.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(64,'Clyde Dicki','Sint at voluptate magni delectus dicta. Et facere consequuntur nihil voluptatum ullam quam. Facere dicta qui repudiandae.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(65,'Gracie Roberts Jr.','Alias ipsa quia similique vitae. Ipsam quia voluptatem quam atque inventore. Eius omnis ipsum aspernatur quod odio. Deleniti mollitia maxime nobis suscipit vel laborum totam.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(66,'Alexanne Effertz','Impedit quibusdam perspiciatis aut qui quis. Perspiciatis eum accusantium quam excepturi. Ab porro alias placeat at aut vitae et autem.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(67,'Reggie Pfeffer','Nam odit odio voluptas dolores perspiciatis maiores nisi praesentium. Ea quidem qui est nulla. Placeat dolor saepe cupiditate atque. Consequuntur minima dignissimos animi aperiam.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(68,'Elta Thiel','Autem est ut et aliquam temporibus est ipsa. Dignissimos aut et eos error ea rerum repellat dolores. Soluta dolorem suscipit dolorem.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(69,'Dr. Laverne Morar I','Ea quae alias harum et praesentium. Nihil perferendis sunt est incidunt enim tempore a aut. Est quibusdam et et ut dolorum quo. Dolore illo qui autem nostrum repellat.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(70,'Emilia Fritsch','Natus commodi est ad dolores numquam. Consectetur ut placeat quo animi vel sit. Debitis et ut sed et quia et. Id nemo est aut eligendi.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(71,'Mrs. Charity Hickle','Voluptas suscipit assumenda doloribus provident quam molestiae eveniet. Ullam quo id aut a delectus tempore enim. Quod dignissimos amet dolorem quia numquam incidunt. Ullam veniam perferendis minima suscipit. Suscipit veritatis est quo non repellendus consequatur nihil.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(72,'Skyla Barton','Odio quasi consequatur in provident aperiam dolorum rem aliquid. Beatae ut nobis exercitationem voluptate nisi enim est et. Sapiente eaque consectetur quo consectetur. Nemo temporibus temporibus asperiores minus iste quisquam veniam voluptatem.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(73,'Adelia Stracke Jr.','Dolores dolorem ut quae eius soluta. Nemo recusandae laborum nostrum aut consequatur tenetur ut. In itaque doloribus labore sequi at voluptate est quae. Et dolorum rerum rerum hic omnis consectetur pariatur.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(74,'Sammie Pfannerstill','Est odio et accusantium illum rerum minima ab doloremque. Ea eum sunt fugiat quia. Sint error sequi consequatur et dolorem. Et delectus sed nam.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(75,'Prof. Alan Torphy Sr.','Autem expedita saepe eveniet nostrum sed velit dolores. Ea voluptatum enim labore quasi. Placeat suscipit vel et quis. Asperiores possimus natus omnis nihil et. Voluptas sint reiciendis iste sint voluptatem quia eos et.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(76,'Verda Berge','Aliquid vero et et. Consequatur sunt ut illo. Ullam molestias consectetur optio sit. Fuga enim est aliquid voluptatem voluptas laborum aut.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(77,'Delmer Skiles','Facilis unde consequuntur exercitationem velit. Voluptate sunt aspernatur mollitia illum. Dolores odio qui sapiente. Voluptatem et ut velit est sint non quia beatae.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(78,'Zion Dietrich PhD','Omnis velit dolorem omnis. Pariatur quia nemo laudantium. Ex saepe hic suscipit architecto porro. Qui tempore est quaerat molestiae.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(79,'Mr. Lucious Lehner','Cumque sequi et ad at nihil consectetur odit. Enim omnis architecto id fugiat sit. Vero sint illum et sunt sunt laboriosam. Consequatur voluptas mollitia magni non quod magni neque.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(80,'Laura Jacobson','Consequuntur omnis dolorem et id ea. Qui iure dignissimos velit ut et sit. Sed quos eaque fugiat velit aut ex et.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(81,'Dayna Grady I','Molestias non inventore quas optio debitis. Ducimus blanditiis tempora quia molestiae omnis. Voluptatem eos officiis a doloribus omnis. Alias ex id dignissimos.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(82,'Precious Upton','Maxime ducimus aliquam vero veritatis fugit laborum. Dolor doloremque expedita quae est. Beatae accusantium corporis exercitationem molestiae optio consequatur deleniti. Omnis autem eos voluptas itaque sit eaque.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(83,'Mr. Sammie Wilkinson V','Vel suscipit ut soluta omnis. Quidem aut eum autem dolorem.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(84,'Olga Legros','A explicabo ipsa libero voluptatem aperiam recusandae praesentium. Aut sunt minima et quidem omnis maxime qui. Eum et quod reprehenderit adipisci voluptatum incidunt.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(85,'Sabryna Weimann PhD','Eveniet et ipsum blanditiis consequuntur doloremque distinctio. Commodi quia laboriosam ut quo. Quos itaque in odit et.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(86,'Hilbert Keebler','Provident nemo praesentium et rerum est. Quisquam nihil ut dolore dolor aspernatur. Magni dolore nihil sed non nihil. Accusamus qui numquam quas excepturi delectus blanditiis consequatur.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(87,'Doyle DuBuque','Non qui ea veritatis explicabo optio reiciendis tempore. Eum sunt deleniti perferendis dolorem quam vitae. Libero cum voluptatibus ea ad similique fugit.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(88,'Jody Turner','Iste quibusdam dolores quia officia et dolores. Hic doloribus quibusdam est inventore. Suscipit non consequuntur et necessitatibus ipsum. Unde deserunt eum nisi minus rerum.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(89,'Mr. London Daniel','In et voluptate dolore est quis vero eum. Omnis deserunt dicta nemo est voluptatem. Unde eaque velit eaque adipisci. Ad deleniti et velit magnam aspernatur sint harum magni.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(90,'Christina Anderson','Adipisci earum molestiae nostrum cupiditate et. Suscipit iure accusamus nemo autem.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(91,'Modesta Volkman','In voluptatem non quia quisquam. Quidem adipisci fugit ut dolor. Ut veniam error omnis neque iste eum iusto. Quod autem dolorum occaecati nihil dolorem ipsum maiores.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(92,'Reuben Bergnaum','Ea nihil qui repellendus natus harum sit. Assumenda nobis distinctio dolor id unde qui recusandae quos. Esse similique amet fuga itaque alias deleniti. Aut at facilis doloremque enim quo sint. Expedita quibusdam et debitis.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(93,'Ms. Nikki Feil IV','Aut eos nihil in illo. Optio sed molestiae aspernatur quia veritatis magnam perferendis. Veritatis illum quisquam provident maxime illo voluptas porro. Totam temporibus maiores voluptatem dignissimos est et.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(94,'Jabari Oberbrunner','Explicabo et vel quam nulla distinctio veniam minima qui. Omnis consequatur vel iure blanditiis.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(95,'Orion Herzog','Perferendis qui magni nesciunt dignissimos eos minima perferendis. Dolore vel iusto eos sed id molestiae nihil voluptatum. Aliquam vero laborum ut odit est sunt repellendus dolor.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(96,'Dr. Roscoe Kling IV','Voluptatibus odit eos sint qui laudantium. Ipsa qui aut nam eum ut debitis reiciendis. Repellat esse vel vero voluptatem. Rem voluptatem corrupti voluptas molestias omnis.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(97,'Dr. Josh Feil','Magni facilis dolorem id. Qui eligendi non magnam tenetur dolorem alias expedita repellat. Voluptas et deleniti quis laboriosam sit labore fugit. Quia sed atque porro tenetur dolor.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(98,'Felicita Thiel','Ea deleniti labore blanditiis quia numquam aut. Ut aperiam neque mollitia illo animi. Veritatis odit dolorem nisi voluptate voluptate dolores voluptas.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(99,'Verdie Schuppe','Accusamus sint corrupti ut sint iste iure architecto alias. Laborum qui fugit voluptatibus est.','2023-01-31 15:45:07','2023-01-31 15:45:07'),(100,'Agnes Pfannerstill','Autem reprehenderit excepturi est harum est consectetur. Illo ratione aperiam suscipit eligendi voluptatum doloribus saepe. Illo in est ducimus iste eos maxime. Occaecati consequatur commodi aut rerum rerum eum aut.','2023-01-31 15:45:07','2023-01-31 15:45:07');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qa_messages`
--

DROP TABLE IF EXISTS `qa_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qa_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `topic_id` bigint(20) unsigned NOT NULL,
  `sender_id` bigint(20) unsigned NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `qa_messages_topic_id_foreign` (`topic_id`),
  KEY `qa_messages_sender_id_foreign` (`sender_id`),
  CONSTRAINT `qa_messages_sender_id_foreign` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `qa_messages_topic_id_foreign` FOREIGN KEY (`topic_id`) REFERENCES `qa_topics` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qa_messages`
--

LOCK TABLES `qa_messages` WRITE;
/*!40000 ALTER TABLE `qa_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `qa_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qa_topics`
--

DROP TABLE IF EXISTS `qa_topics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qa_topics` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creator_id` bigint(20) unsigned NOT NULL,
  `receiver_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `qa_topics_creator_id_foreign` (`creator_id`),
  KEY `qa_topics_receiver_id_foreign` (`receiver_id`),
  CONSTRAINT `qa_topics_creator_id_foreign` FOREIGN KEY (`creator_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `qa_topics_receiver_id_foreign` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qa_topics`
--

LOCK TABLES `qa_topics` WRITE;
/*!40000 ALTER TABLE `qa_topics` DISABLE KEYS */;
/*!40000 ALTER TABLE `qa_topics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_user` (
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  KEY `user_id_fk_7863556` (`user_id`),
  KEY `role_id_fk_7863556` (`role_id`),
  CONSTRAINT `role_id_fk_7863556` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_id_fk_7863556` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,1);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin',NULL,NULL,NULL),(2,'User',NULL,NULL,NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` datetime DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','ce.pichardo@gmail.com',NULL,'$2y$10$gx4z6791Ypib4jxuS/Zyt.gQ4ZyMHZ9T1371jYDeQTeaahaCOyjaG',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-01-31 16:20:33
